A simple demo:
SEG-MAT -m data\teddy.off -b data\teddy_mat.ma -s data\teddy_smat.ma

Usage: SEG-MAT [-h,--help] -m,--mesh -b,--bmat -s,--smat [-g,--grow] [-n,--min] [-p,--prim]
Arguments:
    -h, --help    show this help message and exit
    -m, --mesh    path to the surface mesh (.off)
    -b, --bmat    path to the base MAT (.ma)
    -s, --smat    path to the structure MAT (.ma)
    -g, --grow    (optional) growing threshold, default 0.015
    -n, --min     (optional) minmal region, default 0.002
    -p, --prim    (optional) whether to compute the primitive representation (0:no, 1:yes)

MAT Computation:
Given a 3D mesh, we use [Q-MAT](http://cgcad.thss.tsinghua.edu.cn/wangbin/qmat/qmat.html) to compute the base MAT and structure MAT for segmentation. The Q-MAT software is packed in the folder. 
The Q-MAT simplification is based on vertex number, while we recommend the users to set the vertex number of the base MAT to 2000, and the vertex number of the structured MAT to max{0.1%*intial_MAT_vertex_number, 15}.
For a non-watertight or a poor-quality mesh, you may need to first convert the mesh to a watertight one using the [tool](https://github.com/hjwdzh/Manifold) to benefit the MAT computation.  